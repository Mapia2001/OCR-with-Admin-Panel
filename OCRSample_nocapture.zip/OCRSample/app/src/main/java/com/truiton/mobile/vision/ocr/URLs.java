package com.truiton.mobile.vision.ocr;

public class URLs {

    private static final String ROOT_URL = "http://containerlog.co.za//api/login/api.php?apicall=";
//    private static final String ROOT_URL = "http://192.168.209.45/api/login/api.php?apicall=";

//    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN= ROOT_URL + "login";
    public static final String URL_SAVE=ROOT_URL + "savescan";
}